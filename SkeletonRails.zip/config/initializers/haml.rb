# The following stops haml prettifying the html in dev mode which sometimes causes it to look different to production
Haml::Template.options[:ugly] = true