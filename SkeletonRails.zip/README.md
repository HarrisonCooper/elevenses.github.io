# elevenses_github_io
---

### Description
Describe your app here...

### Significant Features/Technology
The system has the following:

* Some significant thing...
* Another one...

### Special Development Pre-requisites
None.

### Deployment
*QA -> Demo -> Production* using the `epi-deploy` gem.

### Customer Contact
Some Customer <some.customer@epigenesys.co.uk>
